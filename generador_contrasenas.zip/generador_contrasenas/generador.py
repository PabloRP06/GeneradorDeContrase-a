import random
import string

# 1. Definir los conjuntos de caracteres
MINUSCULAS = string.ascii_lowercase
MAYUSCULAS = string.ascii_uppercase
NUMEROS = string.digits
SIMBOLOS = string.punctuation

def generar_contrasena(longitud, incluir_mayusculas, incluir_numeros, incluir_simbolos):
    # 2. Inicializar el "Pool" total de caracteres
    caracteres_pool = MINUSCULAS  # Las minúsculas siempre están incluidas

    if incluir_mayusculas:
        caracteres_pool += MAYUSCULAS
    if incluir_numeros:
        caracteres_pool += NUMEROS
    if incluir_simbolos:
        caracteres_pool += SIMBOLOS

    # Verificar que el pool no esté vacío (aunque con minúsculas siempre habrá algo)
    if not caracteres_pool:
        print("Error: Debes incluir al menos un tipo de caracter.")
        return None
    
    # 3. Generar la Contraseña
    # Usamos random.choice() para elegir N veces del pool.
    contrasena = ''.join(random.choice(caracteres_pool) for _ in range(longitud))
    
    return contrasena

def main():
    print("\n--- Generador de Contraseñas Seguras ---")
    
    # 1. Solicitar Longitud
    while True:
        try:
            longitud = int(input("Introduce la longitud deseada (ej. 12): "))
            if longitud < 4:
                print("La longitud debe ser de al menos 4 caracteres para ser segura.")
            else:
                break
        except ValueError:
            print("Entrada no válida. Por favor, introduce un número.")

    # 2. Recopilar Requisitos (Sí/No)
    # Una forma simple de convertir 'y'/'s' a True y cualquier otra cosa a False
    incluir_mayusculas = input("¿Incluir mayúsculas? (s/n): ").lower() in ('s', 'y')
    incluir_numeros = input("¿Incluir números? (s/n): ").lower() in ('s', 'y')
    incluir_simbolos = input("¿Incluir símbolos? (s/n): ").lower() in ('s', 'y')
    
    # Llamar a la función generadora
    contrasena_final = generar_contrasena(
        longitud, 
        incluir_mayusculas, 
        incluir_numeros, 
        incluir_simbolos
    )
    
    # 5. Mostrar resultado
    if contrasena_final:
        print("\n🔑 ¡Contraseña Generada Exitosamente!")
        print(f"Contraseña: {contrasena_final}")
        print("-" * 30)

# Punto de entrada del script
if __name__ == "__main__":
    main()