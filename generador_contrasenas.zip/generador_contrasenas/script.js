// 1. Definir los conjuntos de caracteres
const MINUSCULAS = "abcdefghijklmnopqrstuvwxyz";
const MAYUSCULAS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const NUMEROS = "0123456789";
const SIMBOLOS = "!@#$%^&*()_+-=[]{}|;:,.<>?/~`";

// 2. Obtener referencias a elementos del DOM
const display = document.getElementById('password-display');
const lengthInput = document.getElementById('length');
const mayusCheck = document.getElementById('mayus');
const numerosCheck = document.getElementById('numeros');
const simbolosCheck = document.getElementById('simbolos');
const generateButton = document.getElementById('generate-button');
const copyButton = document.getElementById('copy-button');
const errorMsg = document.getElementById('error-msg');

// Función principal de generación
function generarContrasena() {
    errorMsg.textContent = ''; // Limpiar errores anteriores
    
    // Obtener valores del usuario
    const longitud = parseInt(lengthInput.value);
    const incluirMayus = mayusCheck.checked;
    const incluirNumeros = numerosCheck.checked;
    const incluirSimbolos = simbolosCheck.checked;

    // Validación básica
    if (longitud < 4 || isNaN(longitud)) {
        errorMsg.textContent = 'La longitud debe ser al menos 4.';
        display.textContent = 'ERROR';
        return;
    }

    // 3. Construir el "Pool" Total de Caracteres
    let caracteresPool = MINUSCULAS; // Minúsculas siempre incluidas
    if (incluirMayus) caracteresPool += MAYUSCULAS;
    if (incluirNumeros) caracteresPool += NUMEROS;
    if (incluirSimbolos) caracteresPool += SIMBOLOS;
    
    if (caracteresPool === MINUSCULAS && (!incluirMayus && !incluirNumeros && !incluirSimbolos)) {
        // En este caso, solo hay minúsculas, lo cual está bien.
    } else if (caracteresPool === '') {
        // Esto solo pasaría si no incluimos las minúsculas, pero las estamos incluyendo por defecto.
        errorMsg.textContent = 'Selecciona al menos un tipo de caracter.';
        display.textContent = 'ERROR';
        return;
    }

    // 4. Generar la Contraseña
    let contrasena = '';
    for (let i = 0; i < longitud; i++) {
        // Escoger un índice aleatorio del pool y añadir ese carácter
        const randomIndex = Math.floor(Math.random() * caracteresPool.length);
        contrasena += caracteresPool.charAt(randomIndex);
    }

    // 5. Mostrar y Actualizar
    display.textContent = contrasena;
}

// 6. Añadir Event Listeners
generateButton.addEventListener('click', generarContrasena);

copyButton.addEventListener('click', () => {
    // Usar la API de Portapapeles para copiar el texto
    navigator.clipboard.writeText(display.textContent).then(() => {
        const originalText = copyButton.textContent;
        copyButton.textContent = '¡Copiado!';
        setTimeout(() => {
            copyButton.textContent = originalText;
        }, 1500);
    }).catch(err => {
        console.error('Error al copiar: ', err);
    });
});

// Generar una contraseña inicial al cargar la página
generarContrasena();